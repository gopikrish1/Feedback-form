import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { db } from "../firebase";
import { collection, query, where, onSnapshot, addDoc } from "firebase/firestore";

const generateUsername = () => {
  const adjectives = ["Rare", "Lateral", "Curious", "Gentle"];
  const nouns = ["Rabbit", "Moon", "Tiger", "Eagle"];
  return `${adjectives[Math.floor(Math.random() * adjectives.length)]} ${nouns[Math.floor(Math.random() * nouns.length)]}`;
};

const Room = () => {
  const { roomId } = useParams();
  const [feedbacks, setFeedbacks] = useState([]);
  const [activeUsers, setActiveUsers] = useState(0);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [username, setUsername] = useState(generateUsername());
  const [isCreator, setIsCreator] = useState(false);

  useEffect(() => {
    if (!roomId) {
      console.error("❌ Room ID is missing!");
      return;
    }

    const storedCreator = localStorage.getItem("roomCreator");
    setIsCreator(storedCreator === roomId);

    const feedbacksRef = collection(db, "feedbacks");
    const feedbackQuery = query(feedbacksRef, where("roomId", "==", roomId));
    const unsubscribeFeedbacks = onSnapshot(feedbackQuery, (snapshot) => {
      setFeedbacks(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
    });

    const usersRef = collection(db, "roomUsers");
    const usersQuery = query(usersRef, where("roomId", "==", roomId));
    const unsubscribeUsers = onSnapshot(usersQuery, (snapshot) => {
      setActiveUsers(snapshot.docs.length);
    });

    const addUserToRoom = async () => {
      try {
        await addDoc(usersRef, { roomId, joinedAt: new Date(), username });
        console.log(`✅ User "${username}" joined room ${roomId}`);
      } catch (error) {
        console.error("❌ Error adding user to room:", error);
      }
    };

    addUserToRoom();

    return () => {
      unsubscribeFeedbacks();
      unsubscribeUsers();
    };
  }, [roomId]);

  const submitFeedback = async () => {
    const parsedRating = Number(rating);
    if (parsedRating < 1 || parsedRating > 5 || comment.trim() === "") {
      alert("❌ Please provide a valid rating (1-5) and a comment.");
      return;
    }
    try {
      await addDoc(collection(db, "feedbacks"), { roomId, username, rating: parsedRating, comment });
      setRating(0);
      setComment("");
      alert(`✅ Feedback submitted successfully! (${username})`);
    } catch (error) {
      console.error("❌ Error submitting feedback:", error);
      alert("❌ Error submitting feedback.");
    }
  };

  return (
    <div className="container mt-5">
      <h2>Room: {roomId}</h2>

      {isCreator && <p>👥 Active Users: {activeUsers}</p>}

      {isCreator ? (
        <>
          <h3>Feedbacks from Users:</h3>
          {feedbacks.length === 0 ? (
            <p>No feedback yet.</p>
          ) : (
            <table className="table table-striped">
              <thead>
                <tr>
                  <th>Username</th>
                  <th>Rating</th>
                  <th>Comment</th>
                </tr>
              </thead>
              <tbody>
                {feedbacks.map((fb) => (
                  <tr key={fb.id}>
                    <td>{fb.username}</td>
                    <td>{fb.rating}⭐</td>
                    <td>{fb.comment}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </>
      ) : (
        <>
          <h3>Give Feedback</h3>
          <p>Hey <strong>{username}</strong>, your feedback matters a lot! 😊</p>

          <input
            type="number"
            className="form-control my-2"
            value={rating}
            onChange={(e) => setRating(e.target.value)}
            placeholder="Rating (1-5)"
            min="1"
            max="5"
          />

          <input
            type="text"
            className="form-control my-2"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Your feedback"
          />

          <button className="btn btn-primary" onClick={submitFeedback}>
            Submit Feedback
          </button>
        </>
      )}
    </div>
  );
};

export default Room;
